const Post = require("../models/post");

//all the middleware goes here
var middlewareObj = {};

middlewareObj.checkPostOwnership = function (req, res, next) {
  if (req.isAuthenticated()) {
    Post.findById(req.params.id, (err, foundPost) => {
      if (err) {
        res.redirect("back");
      } else {
        //does user own the post checking
        if (foundPost.author.id.equals(req.user._id)) {
          next();
        } else {
          res.redirect("back");
        }
      }
    });
  } else {
    res.redirect("back");
  }
};

middlewareObj.isLoggedIn = function (req, res, next) {
  if (req.isAuthenticated()) {
    next();
  }
  else {
    res.redirect("/login");
  }
};

middlewareObj.gotoProfileHomeIfLoggedIn = function(req,res,next) {
  if (req.isAuthenticated()) {
    res.redirect("/user/"+req.user.userId);
  }
  else {
    next();
  }
}

module.exports = middlewareObj;
