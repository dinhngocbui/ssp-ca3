const SUCCESSFUL = 0;
const FAIL = 400;
const ENTITY_EXISTS = 200;
const ENTITY_UNKNOWN = 404;
const UNAUTHORIZED = 401

const createReponse = function(code,message,body=undefined) {
    var response = {code,message};
    if (body!==null && body!==undefined) {
        response.body = body;
    }
    return response;
}

module.exports = {
    SUCCESSFUL,
    FAIL,
    ENTITY_EXISTS,
    ENTITY_UNKNOWN,
    UNAUTHORIZED,
    createReponse
}