/*var Post = {
  postId: "",
  author: {
    userId: "",
    username: ""
  },
  image: "",
  title: "",
  description: "",
  comments: []
};*/

const db = require("../database");
const User = require("./user");
const dbhelper = require("./dbhelper");

const find = function (filter, callback) {
  // no callback no execution
  if (!callback) return;
  // find post by any of postId, authorId 
  // if nothing is supplied as filter then return all posts
  const postId = filter.postId;
  const authorId = filter.authorId;
  var response = null;
  try {
    if (postId) {
      // find by post id
      const result = db.findPostById(postId);
      if (result) {
        response = dbhelper.createReponse(dbhelper.ENTITY_EXISTS,"",result);
      }
      else {
        response = dbhelper.createReponse(dbhelper.ENTITY_UNKNOWN,"no post found");
      }
    }
    else if (authorId) {
      // find by author id
      const result = db.findPostByAuthor(authorId);
      response = dbhelper.createReponse(dbhelper.SUCCESSFUL,"",result);
    }
    else {
      // return all posts from all users
      const result = db.getAllPosts();
      response = dbhelper.createReponse(dbhelper.SUCCESSFUL,"",result);
    }
    callback(null,response);
  }
  catch (e) {
    callback(e, null);
  }
}

const create = function (post, callback) {
  // no callback no execution
  if (!callback) return;
  try {
    const newPost = db.addPost(post);
    callback(null,dbhelper.createReponse(dbhelper.SUCCESSFUL,"post created",newPost));
  }
  catch(e) {
    callback(e,null);
  }
}

const findById = function (postId, callback) {
  find({ postId }, callback);
}

module.exports = {
  find, create, findById
};