const db = require("../database");
const dbhelper = require("./dbhelper");


const findById = function (userId, callback) {
    if (!userId || !callback) return;
    try {
        var user = db.findUserByUserId(userId);
        if (user) {
            callback(null, dbhelper.createReponse(dbhelper.ENTITY_EXISTS, "", user))
        }
        else {
            callback(null, dbhelper.createReponse(dbhelper.ENTITY_UNKNOWN, "user does not exists"));
        }
    }
    catch (e) {
        callback(e, null);
    }
}

const register = function (user, callback) {
    if (!user || !callback) return;
    try {
        const username = user.username;
        const hasNoUser = null === db.findUserByUsername(username);
        if (hasNoUser) {
            const newUser = db.addUser(user);
            callback(null, dbhelper.createReponse(dbhelper.SUCCESSFUL, "user registered", newUser));
        }
        else {
            callback(null, dbhelper.createReponse(dbhelper.ENTITY_EXISTS, "user exists"));
        }
    }
    catch (e) {
        callback(e, null);
    }
}

const authenticateUser = function (req, username, password, OnComplete) {
    try {
        const user = db.findUserByUsername(username);
        if (!user) {
            req.authenticator = { code: dbhelper.ENTITY_UNKNOWN};
            OnComplete(null, false);
        }
        else if (user.password === password) {
            req.authenticator = { code: dbhelper.SUCCESSFUL};
            OnComplete(null, user);
        }
        else {
            req.authenticator = { code: dbhelper.UNAUTHORIZED};
            OnComplete(null, false);
        }
    }
    catch (e) {
        OnComplete(e, false);
    }
}

const serializeUser = function (user, OnComplete) {
    if (user) {
        OnComplete(null, JSON.stringify(user));
    }
}

const deserializeUser = function (data, OnComplete) {
    if (data) {
        OnComplete(null, JSON.parse(data));
    }
}

module.exports = {
    findById, register, authenticateUser, serializeUser, deserializeUser
};
