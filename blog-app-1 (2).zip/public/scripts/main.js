const STRONG_PASSWORD_PATTERN = /(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.{8,20})/;

function validateStrongPassword(text, callback = undefined) {
    if (!text) return false;
    return STRONG_PASSWORD_PATTERN.test(text);
}

function validateImageFile(imageFiles, callback = undefined) {
    if (imageFiles) {
        const VALID_IMAGE_EXTENSIONS = ["png","jpg","jpeg","gif","webp","bmp"];
        var [file] = imageFiles;
        var name = file.name;
        var dotIndex = name.lastIndexOf(".");
        // image file name must be atleast 1 chracter long
        // so the index of extension name period must be >= 1
        if (dotIndex >= 1) {
            var ext = name.substring(dotIndex+1);
            ext = ext.toLowerCase();
            if (VALID_IMAGE_EXTENSIONS.find((v) => {return v===ext;})) {
                if (callback) {
                    callback({filename:name,extension:ext,valid:true});
                }
            }
            else if (callback) {
                callback({filename:name,extension:ext,valid:false});
            }
        }
    }
}

function togglePasswordVisibility(elementSelector) {
    const node = document.querySelector(elementSelector);
    if (node && node instanceof HTMLInputElement) {
        const isVisible = node.type.toLowerCase() == "text";
        if (isVisible) {
            node.type = "password";
        }
        else {
            node.type = "text";
        }
    }
}

function previewImage(previewElementSelector, inputFiles) {
    if (previewElementSelector && inputFiles) {
        var previewElement = document.querySelector(previewElementSelector);
        if (previewElement) {
            var [file] = inputFiles;
            var url = URL.createObjectURL(file);
            previewElement.src = url;
        }
    }
}