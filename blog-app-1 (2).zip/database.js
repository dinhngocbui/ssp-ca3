
const path = require("path");
const fs = require("fs");
const { v4: uuidv4 } = require("uuid");

const db_file_name = process.env.DB_FILE;

const DB_DATA_EMPTY = {
    users: [],
    posts: []
};

var db = {
    connected: false,
    data: null
};

db.connect = function () {
    if (db.connected) return;
    try {
        const data = fs.readFileSync(db_file_name, { encoding: "utf-8" });
        if (data) {
            db.data = JSON.parse(data);
        }
        else {
            db.data = DB_DATA_EMPTY;
        }
        db.connected = true;
    }
    catch (e) {
        console.log("error connecting ", e);
        db.connected = false;
        db.data = null;
    }
}

db.save = function () {
    if (!db.connected) return;
    const data = JSON.stringify(db.data);
    try {
        fs.writeFileSync(db_file_name, data);
    }
    catch (e) {
        console.log("error saving ", e);
    }
}

db.disconnect = function () {
    if (!db.connected) return;
    db.save();
    db.connected = false;
    db.data = null;
}

db.addUser = function (user) {
    db.connect();
    user.userId = uuidv4();
    db.data.users.push(user);
    db.save();
    return user.userId;
}

db.addPost = function (post) {
    db.connect();
    post.postId = uuidv4();
    db.data.posts.push(post);
    db.save();
    return post;
}

db.getAllUsers = function () {
    db.connect();
    const users = db.data["users"];
    if (!users) {
        db.data["users"] = [];
    }
    return db.data["users"];
}

db.getAllPosts = function () {
    db.connect();
    const posts = db.data.posts;
    if (!posts) {
        db.data.posts = [];
    }
    return db.data.posts;
}

db.deletePost = function (postId) {
    db.connect();
    const posts = db.getAllPosts();
    const post = findPostById(postId);
    if (post) {
        const index = posts.indexOf(post);
        posts.splice(index, 1);
        db.save();
        return true;
    }
    return false;
}

db.findUserByUsername = function (username) {
    db.connect();
    const users = db.getAllUsers();
    var result = users.find((user) => { return user.username == username; })
    return result ? result : null;
}

db.findUserByUserId = function (userId) {
    db.connect();
    const users = db.getAllUsers();
    var result = users.find((user) => { return user.userId == userId; });
    return result ? result : null;
}

db.findPostById = function (postId) {
    db.connect();
    const posts = db.getAllPosts();
    const result = posts.find((post) => { return post.postId == postId; });
    return result ? result : null;
}

db.findPostByAuthor = function (userId) {
    db.connect();
    const posts = db.getAllPosts();
    const result = posts.filter((post) => { return post.author.userId == userId; });
    return result ? result : [];
}

module.exports = db;