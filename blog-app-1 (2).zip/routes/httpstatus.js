const express = require("express");
const router = express.Router({ mergeParams: true });

router.get("/404", (req, res) => {
    res.render("httpstatus/httpstatuscodewithmessage", {
        layout: "layouthttpstatus",
        pageTitle: "404",
        statusCodeGraphic: "/media/404.jpg",
        statusMessage: ""
    })
});

router.get("/500", (req, res) => {
    res.render("httpstatus/httpstatuscodewithmessage", {
        layout: "layouthttpstatus",
        pageTitle: "500",
        statusCodeGraphic: "/media/500.jpg",
        statusMessage: ""
    })
});

module.exports = router;
