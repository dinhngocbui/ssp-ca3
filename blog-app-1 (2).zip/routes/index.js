const express = require("express");
const router = express.Router();
const passport = require("passport");
const User = require("../models/user");
const dbhelper = require("../models/dbhelper");
const middleware = require("../middleware");
const { response } = require("express");

router.get("/", (req, res) => {
  res.render("home", { pageTitle: "Home" });
});

//show register form
router.get("/register", middleware.gotoProfileHomeIfLoggedIn, (req, res) => {
  res.render("register", { pageTitle: "Register" });
});

//handle signup logic
router.post("/register", (req, res) => {
  const email = req.body.email;
  const password = req.body.password;

  const newUser = {
    username: email,
    password: password
  };

  User.register(newUser, (err, response) => {
    if (err) {
      // show 500
      console.log(err);
      res.redirect("/500");
    }
    else if (response.code == dbhelper.SUCCESSFUL) {
      res.redirect("/login");
    }
    else {
      res.render("register", { pageTitle: "Register", REG_RES_CODE: response.code })
    }
  });
});

// show login form
router.get("/login", middleware.gotoProfileHomeIfLoggedIn, (req, res) => {
  res.render("login", { pageTitle: "LogIn" });
});

//handle login logic
router.post("/login",
  passport.authenticate("local", {
    successRedirect: "/posts",
    failureRedirect: "/login"
  }),
  (req, res) => { });

//logic route
router.get("/logout", (req, res) => {
  req.logout();
  res.redirect("/posts");
});

module.exports = router;
