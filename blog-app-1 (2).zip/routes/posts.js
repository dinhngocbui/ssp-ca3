const express = require("express");
const router = express.Router({ mergeParams: true });
const Post = require("../models/post");
const middleware = require("../middleware");
const path = require("path");
const fs = require("fs");
const multer = require("multer");
const dbhelper = require("../models/dbhelper");

const MAX_UPLOAD_SIZE_BYTES = 10 * 1024 * 1024; // 10 MB

//------------MULTER CONFIGURATION-----------
var UPLOAD_STOTAGE = multer.diskStorage({
  destination: function (req, file, callback) {
    const user = req.user;
    if (user) {
      var dir = path.join(__dirname, "..", "public", "uploads", user.userId);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      callback(null, dir);
    }
    else {
      callback("user not logged in", null);
    }
  },
  filename: function (req, file, callback) {
    callback(null,file.originalname);
  }
});

var UPLOAD_CONFIG = multer({
  storage: UPLOAD_STOTAGE,
  limits: {
    fileSize: MAX_UPLOAD_SIZE_BYTES,
  }
});

//------------------------------------------------

// get posts from all users
router.get("/", (req, res) => {
  //Get all posts
  Post.find({}, (err, response) => {
    if (err) {
      console.log(err);
      res.redirect("/500");
    } else {
      res.render("posts/index", {
        pageTitle: "Posts",
        posts: response.body,
        currentUser: req.user,
        showingAllPosts: true
      });
    }
  });
});

//NEW - show form to create new posts
router.get("/publish", middleware.isLoggedIn, (req, res) => {
  res.render("posts/new", { pageTitle: "Create Post" });
});

//CREATE- add new post
router.post("/publish", [middleware.isLoggedIn, UPLOAD_CONFIG.single("image")], (req, res) => {
  const user = req.user;
  var image = path.join("/uploads",user.userId,path.basename(req.file.path));
  var title = req.body.title;
  var description = req.body.description;
  var author = {
    userId: user.userId,
    username: user.username
  };

  var newPost = {
    author, title, description, image
  };

  Post.create(newPost, (err, response) => {
    if (err) {
      console.log(err);
      res.redirect("/500");
    } else {
      const postId = response.body.postId;
      res.redirect("/posts/" + postId);
    }
  });
});

//SHOW - render show template with given id
router.get("/:id", function (req, res) {
  //find the post with provided id
  Post.findById(req.params.id, (err, response) => {
    if (err) {
      console.log(err);
      req.redirect("/500");
    } else {
      //render show template with the post
      const code = response.code;
      if (code == dbhelper.ENTITY_EXISTS) {
        const foundPost = response.body;
        res.render("posts/show", { pageTitle: foundPost.title, post: foundPost });
      }
      else {
        // post not found
        res.redirect("/404");
      }
    }
  });
});

module.exports = router;
