const express = require("express");
const router = express.Router({ mergeParams: true });
const User = require("../models/user");
const Post = require("../models/post");
const dbhelper = require("../models/dbhelper");

router.get("/:userId", (req, res) => {
  const userId = req.params.userId;
  User.findById(userId, (err, resp) => {
    if (err) {
      // show 500
      console.log(err);
      res.redirect("/500");
    }
    else {
      const code = resp.code;
      if (code == dbhelper.ENTITY_EXISTS) {
        Post.find({ authorId: userId }, (err, response) => {
          if (err) {
            // show 500
            console.log(err);
            res.redirect("/500");
          }
          else {
            const currentUser = req.user;
            const author = resp.body;
            const postsbyauthor = response.body;
            res.render("posts/index", {
              pageTitle: "Posts | " + author.username,
              posts: postsbyauthor,
              author: author,
              currentUser: currentUser,
              showingMyPosts: currentUser && author.userId == currentUser.userId
            });
          }
        });
      }
      else {
        // show 404
        res.redirect("/404");
      }
    }
  })
});

module.exports = router;
