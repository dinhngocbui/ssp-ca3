const path = require("path");
const express = require("express");
const dotenv = require("dotenv").config();
const bodyParser = require("body-parser");
const passport = require("passport");
const LocalStrategy = require("passport-local");
const User = require("./models/user");
const hbs = require("express-handlebars");

//-------------GENRAL CONFIGURATION----------
const app = express();
app.set("view engine",".hbs");
app.engine(".hbs",hbs({
  extname: 'hbs',
  defaultLayout: "base",
  layoutsDir: path.join(__dirname,"views","layouts"),
  partialsDir: [
    path.join(__dirname,"views","partials")
  ],
}));

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname,"public")));
//-------------------------------------------

//------------ROUTERS------------------------
const indexRoutes = require("./routes/index");
const postRoutes = require("./routes/posts");
const userRoutes = require("./routes/user");
const httpstatusRoutes = require("./routes/httpstatus");
//---------------------------------------------

//------------PASSPORT CONFIGURATION-----------
app.use(
  require("express-session")({
    secret: process.env.PASSPORT_SECRET,
    resave: false,
    saveUninitialized: false,
  })
);
app.use(passport.initialize());
app.use(passport.session());
passport.use(new LocalStrategy({
  passReqToCallback: true,
},User.authenticateUser));
passport.serializeUser(User.serializeUser);
passport.deserializeUser(User.deserializeUser);

//to get current logged in user
app.use((req, res, next) => {
  res.locals.currentUser = req.user;
  next();
});
//------------------------------------------------

app.use("/", indexRoutes);
app.use("/",httpstatusRoutes);
app.use("/posts", postRoutes);
app.use("/user", userRoutes);

let port = process.env.PORT || 3030;

app.listen(port, () => {
  console.log(`Server Listening at http://localhost:${port}`);
});
